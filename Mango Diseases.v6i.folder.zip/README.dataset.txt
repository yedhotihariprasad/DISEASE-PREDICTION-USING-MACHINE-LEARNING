# Mango Diseases > 2023-03-23 9:17am
https://universe.roboflow.com/freelance-kmtgd/mango-diseases

Provided by a Roboflow user
License: CC BY 4.0

